<?php
App::uses('AppModel', 'Model');
/**
 * Applicant Model
 *
 */
class Slide extends AppModel {

	

}
